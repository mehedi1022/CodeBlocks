public class ShoppingCartSystem {
    public static void main(String[] args) {
        UserMenu menu = new UserMenu();
        menu.start();
    }
}
